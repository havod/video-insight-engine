<?php
/**
 * Template Name: Solutions Page
 *
 * @package Astuse
 */

get_header(); ?>

<div id="root"></div>

<?php get_footer(); ?>