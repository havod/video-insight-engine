<?php
/**
 * The single post template.
 *
 * @package Astuse
 */

get_header(); ?>

<div id="root"></div>

<?php get_footer(); ?>
