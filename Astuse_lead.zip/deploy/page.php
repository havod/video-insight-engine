<?php
/**
 * The default page template.
 *
 * Used for any WordPress "Page" that does not have a more specific
 * template assigned (e.g. page-home.php, page-solutions.php).
 *
 * @package Astuse
 */

get_header(); ?>

<div id="root"></div>

<?php get_footer(); ?>
