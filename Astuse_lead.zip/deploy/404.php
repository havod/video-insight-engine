<?php
/**
 * The 404 (Not Found) template.
 *
 * @package Astuse
 */

get_header(); ?>

<div id="root"></div>

<?php get_footer(); ?>
