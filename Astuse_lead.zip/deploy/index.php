<?php
/**
 * The main template file (required fallback).
 *
 * @package Astuse
 */

get_header(); ?>

<div id="root"></div>

<?php get_footer(); ?>
